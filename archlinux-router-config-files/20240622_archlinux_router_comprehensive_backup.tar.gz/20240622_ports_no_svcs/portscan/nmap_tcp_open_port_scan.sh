nmap -p- $SERVER_IP
