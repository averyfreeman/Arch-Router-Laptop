nmap -sUV -T4 -F --version-intensity 0 $SERVER_IP
